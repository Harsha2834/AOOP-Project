package music;

public class LocalFileAdapter implements MusicSource {
	 private LocalFilePlayer localFilePlayer;

	 public LocalFileAdapter() {
	     this.localFilePlayer = new LocalFilePlayer();
	 }

	 @Override
	 public void play() {
	     localFilePlayer.playLocalFile();
	 }

	 @Override
	 public void stop() {
	     localFilePlayer.stopLocalFile();
	 }
	}
