package music;

class RadioStation {
    public void playRadio() {
        System.out.println("Playing music from a radio station.");
    }

    public void stopRadio() {
        System.out.println("Stopped playing music from a radio station.");
    }
}