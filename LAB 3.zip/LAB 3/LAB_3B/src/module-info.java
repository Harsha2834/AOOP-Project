/**
 * 
 */
/**
 * 
 */
module LAB_3B {
}