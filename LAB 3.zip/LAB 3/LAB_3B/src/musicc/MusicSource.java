package musicc;

//Common interface for all music sources
interface MusicSource {
 void play();
 void stop();
}
