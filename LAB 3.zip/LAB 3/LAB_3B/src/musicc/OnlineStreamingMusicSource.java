package musicc;

class OnlineStreamingMusicSource implements MusicSource {
    private String url;

    public OnlineStreamingMusicSource(String url) {
        this.url = url;
    }

    @Override
    public void play() {
        System.out.println("Streaming music from: " + url);
    }

    @Override
    public void stop() {
        System.out.println("Stopping streaming from: " + url);
    }
}

