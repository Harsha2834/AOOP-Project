package musicc;

public class MusicStreamingApp {
    public static void main(String[] args) {
        // Using Local File Music Source
        MusicSource localSource = new LocalFileMusicSource("song.mp3");
        MusicPlayer localPlayer = new BasicMusicPlayer(localSource);

        // Adding features using Decorator
        MusicPlayer enhancedLocalPlayer = new EqualizerDecorator(new VolumeControlDecorator(localPlayer));

        enhancedLocalPlayer.playMusic();
        enhancedLocalPlayer.stopMusic();

        System.out.println();

        // Using Online Streaming Music Source
        MusicSource streamingSource = new OnlineStreamingMusicSource("http://musicstreaming.com/track");
        MusicPlayer streamingPlayer = new BasicMusicPlayer(streamingSource);

        // Adding features using Decorator
        MusicPlayer enhancedStreamingPlayer = new VolumeControlDecorator(new EqualizerDecorator(streamingPlayer));

        enhancedStreamingPlayer.playMusic();
        enhancedStreamingPlayer.stopMusic();
    }
}
