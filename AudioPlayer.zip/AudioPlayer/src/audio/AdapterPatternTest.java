package audio;

public class AdapterPatternTest {
    public static void main(String[] args) {
        ModernAudioPlayer player = new ModernAudioPlayer();

        player.play("mp3", "song.mp3");  
        player.play("flv", "song.flv");  
    }
}
