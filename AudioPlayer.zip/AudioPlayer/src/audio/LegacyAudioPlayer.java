package audio;


public class LegacyAudioPlayer {
 public void playMp3(String fileName) {
     System.out.println("Playing mp3 file: " + fileName);
 }
}
