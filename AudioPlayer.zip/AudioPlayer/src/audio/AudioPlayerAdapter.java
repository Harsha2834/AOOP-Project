package audio;


public class AudioPlayerAdapter implements MediaPlayer {
 private LegacyAudioPlayer legacyAudioPlayer;

 public AudioPlayerAdapter(LegacyAudioPlayer legacyAudioPlayer) {
     this.legacyAudioPlayer = legacyAudioPlayer;
 }

 @Override
 public void play(String audioType, String fileName) {
     
     if ("mp3".equalsIgnoreCase(audioType)) {
         legacyAudioPlayer.playMp3(fileName);
     } else {
         System.out.println("Invalid audio format: " + audioType + ". Supported format: mp3");
     }
 }
}
