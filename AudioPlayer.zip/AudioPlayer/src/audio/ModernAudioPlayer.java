package audio;


public class ModernAudioPlayer implements MediaPlayer {
 private MediaPlayer adapter;

 @Override
 public void play(String audioType, String fileName) {
     
     if ("mp3".equalsIgnoreCase(audioType)) {
         System.out.println("Playing mp3 file: " + fileName);
     } else {
         adapter = new AudioPlayerAdapter(new LegacyAudioPlayer());
         adapter.play(audioType, fileName);
     }
 }
}
