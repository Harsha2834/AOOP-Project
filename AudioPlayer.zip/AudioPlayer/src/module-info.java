/**
 * 
 */
/**
 * 
 */
module AudioPlayer {
}